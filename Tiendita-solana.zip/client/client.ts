import BN from "bn.js";
import * as web3 from "@solana/web3.js";
//////////////////// Imports ////////////////////
import { PublicKey } from "@solana/web3.js";
import { BN } from "@coral-xyz/anchor";
import type { InventarioTienda } from "../target/types/inventario_tienda";

// Configure the client to use the local cluster
anchor.setProvider(anchor.AnchorProvider.env());

const program = anchor.workspace.InventarioTienda as anchor.Program<InventarioTienda>;


//////////////////// Constantes ////////////////////
const NOMBRE_TIENDA = "Mi Tiendita Solana";
const CODIGO_PRODUCTO = "PROD-001";
const admin = program.provider.publicKey;

//////////////////// Logs base ////////////////////
console.log("Mi direccion (Admin):", admin.toBase58());

//////////////////// PDAs ////////////////////

function pdaTienda(adminPk: PublicKey) {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("tienda"), adminPk.toBuffer()],
    program.programId
  );
}

function pdaProducto(adminPk: PublicKey, codigo: string) {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("producto"), adminPk.toBuffer(), Buffer.from(codigo)],
    program.programId
  );
}

//////////////////// Helpers ////////////////////

async function fetchTienda(pda: PublicKey) {
  return await program.account.tiendaDb.fetch(pda);
}

async function fetchProducto(pda: PublicKey) {
  return await program.account.producto.fetch(pda);
}

//////////////////// Instrucciones ////////////////////

async function inicializarTienda(nombre: string) {
  const [pda_tienda] = pdaTienda(admin);

  try {
    const txHash = await program.methods
      .inicializarTienda(nombre)
      .accounts({
        tiendaDb: pda_tienda,
        admin: admin,
        systemProgram: web3.SystemProgram.programId,
      })
      .rpc();

    console.log("Tienda creada tx:", txHash);
  } catch (e) {
    console.log("La tienda ya existe o hubo un error:", e.message);
  }

  const tiendaAccount = await fetchTienda(pda_tienda);
  console.log(
    "Tienda:",
    tiendaAccount.nombre,
    "| Productos:",
    tiendaAccount.totalProductos.toString()
  );
}

async function agregarProducto(
  codigo: string,
  nombre: string,
  precio: number,
  stock: number,
  categoria: string
) {
  const [pda_tienda] = pdaTienda(admin);
  const [pda_prod] = pdaProducto(admin, codigo);

  const txHash = await program.methods
    .agregarProducto(codigo, nombre, new BN(precio), new BN(stock), categoria)
    .accounts({
      tiendaDb: pda_tienda,
      producto: pda_prod,
      admin: admin,
      systemProgram: web3.SystemProgram.programId,
    })
    .rpc();

  console.log("Producto agregado tx:", txHash);

  const prodAccount = await fetchProducto(pda_prod);
  console.log(
    "Producto guardado:",
    prodAccount.nombre,
    "- Precio:",
    prodAccount.precio.toString()
  );
}

async function actualizarStock(codigo: string, nuevoStock: number) {
  const [pda_prod] = pdaProducto(admin, codigo);

  const txHash = await program.methods
    .actualizarStock(codigo, new BN(nuevoStock))
    .accounts({
      producto: pda_prod,
      admin: admin,
    })
    .rpc();

  console.log("Stock actualizado tx:", txHash);
}

//////////////////// Demo Runner ////////////////////

async function ejecutarPruebas() {
  try {
    // 1. Inicializamos la base de la tienda
    await inicializarTienda(NOMBRE_TIENDA);

    // 2. Agregamos un producto (Codigo, Nombre, Precio, Stock, Categoria)
    await agregarProducto(
      CODIGO_PRODUCTO,
      "Laptop",
      5000000,
      10,
      "Electronica"
    );

    // 3. Modificamos el stock
    await actualizarStock(CODIGO_PRODUCTO, 15);

    console.log("Pruebas finalizadas con exito");
  } catch (error) {
    console.error("Error ejecutando las pruebas:", error);
  }
}

// Ejecutamos el bloque de pruebas
ejecutarPruebas();
